function setupModel(data) {
    // vísum í parrot object
    const model = data.scene.children[0];

    return model;
  
}

export { setupModel };