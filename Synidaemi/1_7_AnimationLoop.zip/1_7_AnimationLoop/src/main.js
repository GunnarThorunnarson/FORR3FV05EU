import { World } from './World/World.js';

/*
 Transformation
*/

function main() {
  // Get a reference to the container element
  const container = document.querySelector('#scene-container');
  // Create an instance of the World app
  const world = new World(container);
  

  // produce a single frame (render on demand)
  // Muna þá eftir að stilla onResize Hook
  // world.render();
  
  // start the animation loop
  world.start();
}
main();