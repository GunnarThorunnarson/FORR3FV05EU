import { createCamera } from './components/camera.js';
// import { createCube } from './components/cube.js';
import { createMeshGroup } from './components/meshGroup.js';
import { createScene } from './components/scene.js';
import { createLights } from './components/lights.js';

import { createControls } from './systems/controls.js';
import { createRenderer } from './systems/renderer.js';
import { Resizer } from './systems/Resizer.js';
import { Loop } from './systems/Loop.js';

// These variables are module-scoped: we cannot access them from outside the module
let camera;
let renderer;
let scene;
let loop;

class World {
  constructor(container) {
    camera = createCamera();
    scene = createScene();
    renderer = createRenderer();
    loop = new Loop(camera, scene, renderer);
    container.append(renderer.domElement);
    
    const controls = createControls(camera, renderer.domElement);
    // const cube = createCube();
    const { ambientLight, mainLight } = createLights();

    // loop.updatables.push(controls);
    // cube snýst sjáfkrafa um 30 gráður pr sec.
    // loop.updatables.push(cube);

    const meshGroup = createMeshGroup();
    loop.updatables.push(controls, meshGroup);

    // scene.add(ambientLight, mainLight, cube);
    scene.add(ambientLight, mainLight, meshGroup);

    const resizer = new Resizer(container, camera, renderer);

  }  
  // Render the scene
  render() {
    renderer.render(scene, camera)
  }

  // call their counterparts in Loop (systems/Loop.js)
  // This is how we’ll provide access to the loop from within main.js:
  start() {
    loop.start();
  }
  
  stop() {
    loop.stop();
  }
}
  
export { World };

